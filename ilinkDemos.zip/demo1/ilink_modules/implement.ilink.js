exports.hello=function(){ console.log("hello hello good day")}

exports.good = "better"