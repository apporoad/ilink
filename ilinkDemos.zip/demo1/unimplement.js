var ilink = require("../index")


ilink.reg(module,"implement")


exports.hello=function(){}

exports.good = "good"