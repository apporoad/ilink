var unimplement = require('./unimplement')

unimplement.hello()
console.log(unimplement.good)